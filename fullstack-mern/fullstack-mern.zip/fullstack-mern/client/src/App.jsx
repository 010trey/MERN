import { useState } from 'react'
import './App.css'
import './style.css'
import Imagelink from './components/Imagelink'


function App() {
  const [count, setCount] = useState(0)

  return (

  
      <Imagelink/>
  

  )
}

export default App
